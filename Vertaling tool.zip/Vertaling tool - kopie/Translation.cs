﻿using System.Collections.Generic;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Xml.Linq;
using System.Xml;

namespace Vertaling_tool.Data
{
    public static class TranslationService
    {
        public static List<string> Resources = new List<string>();


        public static Dictionary<string, List<string>> Translations = null;

        public static void ReadResources(string folder)
        {
            Resources = new List<string>();
            Translations = new Dictionary<string, List<string>>();

            // get files from folder (*.resx)
            // als eerste de Resource.resx

            string[] files = Directory.GetFiles(folder, "resource.resx");

            if (files.Length == 1)
            {
                // lees xmls file en vul dictionary
                // open file als xml
                Resources.Add("Standaard");
            }

            // nu de overige files
            files = Directory.GetFiles(folder, "resource.*.resx");

            foreach (var file in files)
            {
                // lees xmls file en vul dictionary
                // loop files a
                {
                    //Resources.Add(filenaam);

                    //Find alle data objecten
                    {
                        //if (Translations.TryGetValue(name, out value))
                        //{
                        //    value.add("");
                        //}




                        //< data name = "Aanleverdatum" xml: space = "preserve" >
                        //  < value > To delivery date</ value >
                        //</ data >

                    }

                    //loop alle data objecten af
                    //foreach(xmldataobject)
                    //{
                    //    Translations.Add(xmldataobject.name, new List<string>());

                    //}
                    //}
                }
            }

            // functie voor xml lezen
            //class Class1
            //{
            static void Main(string[] args)
            {
                XmlReader reader = XmlReader.Create("//Vertalingtool/resources");

            }
            //}

        }

        public class Translation
        {
            public string Code { get; set; }

            public string Standaard { get; set; }

            public string Engels { get; set; }
            public string Frans { get; set; }


        }
    }
}
